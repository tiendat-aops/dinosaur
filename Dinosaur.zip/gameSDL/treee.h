#ifndef TREE_H
#define TREE_H
#include<bits/stdc++.h>
#include<random>
#include<SDL.h>
#include<SDL_image.h>

using namespace std;

struct Tree
{
    float tree_val =-3;
    SDL_Rect des_tree;

    Tree();
    void Move();
    void Render_Tree(SDL_Renderer *renderer,SDL_Texture * tree_Tex);
};


#endif // TREE_H

