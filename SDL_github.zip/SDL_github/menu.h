#ifndef MENU_H
#define MENU_H
#include<iostream>
#include<SDL.h>

using namespace std;

int show_menu(SDL_Surface *screen);
#endif
