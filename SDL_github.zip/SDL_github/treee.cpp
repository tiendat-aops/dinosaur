#include "treee.h"
#include "setup.h"

using namespace std;

Tree::Tree()
{
    des_tree = {rand()%100+840, 474,30,36};
}

void Tree::Move()
{
    des_tree.x += tree_val;
}

void Tree::Render_Tree(SDL_Renderer *renderer,SDL_Texture * tree_Tex)
{
    SDL_RenderCopy(renderer, tree_Tex, NULL, &des_tree);
}
